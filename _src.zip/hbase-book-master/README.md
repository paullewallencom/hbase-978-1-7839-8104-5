hbase-book
==========

HBase Design Patterns for Packt (HDPP)
