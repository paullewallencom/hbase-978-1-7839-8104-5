CREATE TABLE my_schema.users (
   username varchar primary key,
   firstname varchar,
   lastname varchar,
   email varchar,   
   password varchar,
   created_date timestamp
);